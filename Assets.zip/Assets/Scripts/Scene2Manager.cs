using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Scene2Manager : MonoBehaviour
{
   
    public AudioSource narrationAudio;
    public AudioSource crabSoundEffect;
    public AudioSource uiClickAudio;
    
  
    public GameObject littleTurtle;
    public GameObject crab;
    
 
    public Button audioToggleButton;
    public GameObject audioOnIcon;
    public GameObject audioOffIcon;
    
 
    private bool isAudioMuted = false;
    
    void Start()
    {
        Debug.Log("Scene2_螃蟹相遇 加载完成！");
        
        
        if (audioToggleButton != null)
        {
            audioToggleButton.onClick.AddListener(ToggleAllAudio);
        }
        
       
        UpdateAudioButtonIcon();
        
        InitializeCharacters();
    }
    
    void InitializeCharacters()
    {
       
        if (littleTurtle != null)
        {
            
            littleTurtle.SetActive(true);
        }
        
        if (crab != null)
        {
           
            crab.SetActive(true);
        }
    }
    
   
    public void LoadHomeScene()
    {
        PlayUIClickSound();
        Debug.Log("返回首页");
        SceneManager.LoadScene("MainMenu");
    }

    public void LoadNextScene()
    {
        PlayUIClickSound();
        Debug.Log("前往下一页：清理垃圾");
        SceneManager.LoadScene("Scene3_TrashCleanup");
    }
    
    
    public void LoadPreviousScene()
    {
        PlayUIClickSound();
        Debug.Log("返回上一页：介绍");
        SceneManager.LoadScene("Scene1_Introduction");
    }
    
 
    public void PlayNarration()
    {
        PlayUIClickSound();
        
        if (narrationAudio != null && !isAudioMuted)
        {
            narrationAudio.Play();
            Debug.Log("播放旁白：遇到螃蟹朋友");
            
           
            TriggerCharacterReaction("narration");
        }
        else if (isAudioMuted)
        {
            Debug.Log("声音已静音，无法播放旁白");
        }
        else
        {
            Debug.LogWarning("旁白音频未设置！");
        }
    }
    

    public void PlayCrabSound()
    {
        PlayUIClickSound();
        
        if (crabSoundEffect != null && !isAudioMuted)
        {
            crabSoundEffect.Play();
            Debug.Log("螃蟹打招呼！");
        }
    }
    
    public void OnTurtleClicked()
    {
        PlayUIClickSound();
        Debug.Log("小乌龟被点击了！");
        
        if (littleTurtle != null)
        {
           
            TriggerTurtleAction();
        }
    }
    
  
    public void OnCrabClicked()
    {
        PlayUIClickSound();
        Debug.Log("螃蟹被点击了！");
        
        if (crab != null)
        {
           
            TriggerCrabAction();
        }
        
     
        PlayCrabSound();
    }
    
    
    private void TriggerTurtleAction()
    {
       
        Animator turtleAnimator = littleTurtle.GetComponent<Animator>();
        if (turtleAnimator != null)
        {
            turtleAnimator.SetTrigger("Action");
            Debug.Log("播放小乌龟动画");
        }
        else
        {
            StartCoroutine(TurtleActionAnimation());
        }
    }
    
   
    private void TriggerCrabAction()
    {
        
        Animator crabAnimator = crab.GetComponent<Animator>();
        if (crabAnimator != null)
        {
            crabAnimator.SetTrigger("Action");
            Debug.Log("播放螃蟹动画");
        }
        else
        {
            
            StartCoroutine(CrabActionAnimation());
        }
    }
    
  
    private System.Collections.IEnumerator TurtleActionAnimation()
    {
        Vector3 originalScale = littleTurtle.transform.localScale;
        Vector3 targetScale = originalScale * 1.1f;
        
        
        Vector3 originalPosition = littleTurtle.transform.localPosition;
        Vector3 downPosition = originalPosition - new Vector3(0, 10f, 0);
        Vector3 upPosition = originalPosition + new Vector3(0, 5f, 0);
        
     
        float duration = 0.15f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            littleTurtle.transform.localPosition = Vector3.Lerp(originalPosition, downPosition, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        
        elapsed = 0f;
        while (elapsed < duration)
        {
            littleTurtle.transform.localPosition = Vector3.Lerp(downPosition, upPosition, elapsed / duration);
            littleTurtle.transform.localScale = Vector3.Lerp(originalScale, targetScale, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        
        elapsed = 0f;
        while (elapsed < duration)
        {
            littleTurtle.transform.localPosition = Vector3.Lerp(upPosition, originalPosition, elapsed / duration);
            littleTurtle.transform.localScale = Vector3.Lerp(targetScale, originalScale, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
       
        littleTurtle.transform.localPosition = originalPosition;
        littleTurtle.transform.localScale = originalScale;
    }
    
    
    private System.Collections.IEnumerator CrabActionAnimation()
    {
        Vector3 originalScale = crab.transform.localScale;
        Vector3 targetScale = originalScale * 1.2f;
        
      
        Vector3 originalPosition = crab.transform.localPosition;
        Vector3 leftPosition = originalPosition - new Vector3(10f, 0, 0);
        Vector3 rightPosition = originalPosition + new Vector3(10f, 0, 0);
        
       
        float duration = 0.1f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            crab.transform.localPosition = Vector3.Lerp(originalPosition, leftPosition, elapsed / duration);
            crab.transform.localScale = Vector3.Lerp(originalScale, targetScale, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        
        elapsed = 0f;
        while (elapsed < duration)
        {
            crab.transform.localPosition = Vector3.Lerp(leftPosition, rightPosition, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        
        elapsed = 0f;
        while (elapsed < duration)
        {
            crab.transform.localPosition = Vector3.Lerp(rightPosition, originalPosition, elapsed / duration);
            crab.transform.localScale = Vector3.Lerp(targetScale, originalScale, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
       
        crab.transform.localPosition = originalPosition;
        crab.transform.localScale = originalScale;
    }
    
    
    private void TriggerCharacterReaction(string reactionType)
    {
        switch (reactionType)
        {
            case "narration":
               
                StartCoroutine(CharacterReactionAnimation());
                break;
        }
    }
    
   
    private System.Collections.IEnumerator CharacterReactionAnimation()
    {
        
        if (littleTurtle != null)
        {
            Vector3 turtleOriginalPos = littleTurtle.transform.localPosition;
            littleTurtle.transform.localPosition = turtleOriginalPos + new Vector3(0, 5f, 0);
            yield return new WaitForSeconds(0.1f);
            littleTurtle.transform.localPosition = turtleOriginalPos;
        }
        
        if (crab != null)
        {
            Vector3 crabOriginalPos = crab.transform.localPosition;
            crab.transform.localPosition = crabOriginalPos + new Vector3(0, 3f, 0);
            yield return new WaitForSeconds(0.1f);
            crab.transform.localPosition = crabOriginalPos;
        }
    }
    
    
    public void PlayUIClickSound()
    {
        if (uiClickAudio != null && !isAudioMuted)
        {
            uiClickAudio.Play();
        }
    }
    

    public void ToggleAllAudio()
    {
        PlayUIClickSound();
        
        isAudioMuted = !isAudioMuted;
        
        // 设置所有音频源的静音状态
        AudioSource[] allAudioSources = FindObjectsOfType<AudioSource>();
        foreach (AudioSource audioSource in allAudioSources)
        {
            audioSource.mute = isAudioMuted;
        }
        
        // 更新声音按钮图标
        UpdateAudioButtonIcon();
        
        Debug.Log(isAudioMuted ? "所有声音已静音" : "所有声音已开启");
    }
    
    // 更新声音按钮图标
    private void UpdateAudioButtonIcon()
    {
        if (audioOnIcon != null && audioOffIcon != null)
        {
            audioOnIcon.SetActive(!isAudioMuted);
            audioOffIcon.SetActive(isAudioMuted);
        }
    }
    
    // 提供给外部检查声音状态的方法
    public bool IsAudioMuted()
    {
        return isAudioMuted;
    }
    
    // 当场景销毁时
    void OnDestroy()
    {
        StopAllCoroutines();
    }
}