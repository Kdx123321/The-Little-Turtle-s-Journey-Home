using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenuManager : MonoBehaviour
{
    
    public AudioSource uiClickAudio;          
    public Button startButton;                
    public Button audioToggleButton;          
    public GameObject turtle;                 
    public GameObject audioOnIcon;           
    public GameObject audioOffIcon;           
    
    
    private bool isAudioMuted = false;
    
  
    private Vector3 turtleOriginalPosition;
    private float jumpHeight = 30f;
    private float jumpDuration = 0.5f;
    private float jumpTimer = 0f;
    private bool isJumping = false;
    
    void Start()
    {
        Debug.Log("主菜单加载完成！");
        
       
        if (startButton != null)
        {
            startButton.onClick.AddListener(OnStartButtonClicked);
        }
        
        if (audioToggleButton != null)
        {
            audioToggleButton.onClick.AddListener(ToggleAllAudio);
        }
        
       
        if (turtle != null)
        {
            turtleOriginalPosition = turtle.transform.position;
        }
        
      
        UpdateAudioButtonIcon();
        
        
        StartTurtleJumping();
    }
    
    void Update()
    {
      
        if (isJumping && turtle != null)
        {
            HandleTurtleJump();
        }
    }
    
   
    public void OnStartButtonClicked()
    {
        PlayUIClickSound();
        Debug.Log("开始游戏，前往第一页");
        
        
        StopAllCoroutines();
        
      
        SceneManager.LoadScene("Scene1_Introduction");
    }
    
 
    public void ToggleAllAudio()
    {
        PlayUIClickSound();
        
        isAudioMuted = !isAudioMuted;
        
       
        AudioSource[] allAudioSources = FindObjectsOfType<AudioSource>();
        foreach (AudioSource audioSource in allAudioSources)
        {
            audioSource.mute = isAudioMuted;
        }
        
      
        UpdateAudioButtonIcon();
        
        Debug.Log(isAudioMuted ? "所有声音已静音" : "所有声音已开启");
    }
    
   
    public void PlayUIClickSound()
    {
        if (uiClickAudio != null && !isAudioMuted)
        {
            uiClickAudio.Play();
        }
    }
    
   
    private void UpdateAudioButtonIcon()
    {
        if (audioOnIcon != null && audioOffIcon != null)
        {
            audioOnIcon.SetActive(!isAudioMuted);
            audioOffIcon.SetActive(isAudioMuted);
        }
    }
    
    private void StartTurtleJumping()
    {
        if (turtle != null)
        {
            
            float randomDelay = Random.Range(2f, 4f);
            Invoke("TriggerTurtleJump", randomDelay);
        }
    }
    
   
    private void TriggerTurtleJump()
    {
        if (turtle != null)
        {
            isJumping = true;
            jumpTimer = 0f;
        }
    }
    
    private void HandleTurtleJump()
    {
        jumpTimer += Time.deltaTime;
        
        if (jumpTimer <= jumpDuration)
        {
            
            float progress = jumpTimer / jumpDuration;
            float jumpValue = Mathf.Sin(progress * Mathf.PI) * jumpHeight;
            
            
            Vector3 newPosition = turtleOriginalPosition;
            newPosition.y += jumpValue;
            turtle.transform.position = newPosition;
            
           
            float rotation = Mathf.Sin(progress * Mathf.PI * 2) * 10f;
            turtle.transform.rotation = Quaternion.Euler(0f, 0f, rotation);
        }
        else
        {
            
            turtle.transform.position = turtleOriginalPosition;
            turtle.transform.rotation = Quaternion.identity;
            isJumping = false;
            
           
            StartTurtleJumping();
        }
    }
    
    
    public bool IsAudioMuted()
    {
        return isAudioMuted;
    }
    
   
    void OnDestroy()
    {
       
        CancelInvoke();
    }
}