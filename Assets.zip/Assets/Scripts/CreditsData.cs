using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "CreditsData", menuName = "游戏/致谢数据")]
public class CreditsData : ScriptableObject
{
    [System.Serializable]
    public class CreditSection
    {
        [Header("章节标题")]
        public string sectionTitle;
        
        [Header("章节内容")]
        [TextArea(3, 10)]
        public string sectionContent;
    }
    
    [Header("致谢内容分段")]
    public List<CreditSection> creditSections = new List<CreditSection>();
}