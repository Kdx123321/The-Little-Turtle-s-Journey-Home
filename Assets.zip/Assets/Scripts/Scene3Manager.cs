using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;

public class Scene3Manager : MonoBehaviour
{
   
    public AudioSource narrationAudio;
    public AudioSource trashCleanSound;
    public AudioSource turtleSFX;
    public AudioSource bgmAudio;
    public AudioSource uiSFX;
    
    public Button audioToggleButton;
    public Button narrationButton;  
    public GameObject audioOnIcon;
    public GameObject audioOffIcon;
    private bool isAudioMuted = false;
    private bool isNarrationPlaying = false;
    
  
    private int trashCleaned = 0;
    private int totalTrash = 3;
    
 
    public GameObject trashBottle;
    public GameObject trashBanana;
    public GameObject trashBag;
    
    
    public GameObject littleTurtle;
    
    
    public Text progressText;
    
  
    private bool isTurtleMoving = false;
    private Vector3 turtleOriginalPosition;
    private Color originalTextColor;
    
    void Start()
    {
        Debug.Log("Scene3_垃圾清理 加载完成！");
        trashCleaned = 0;
        
        
        if (progressText != null)
        {
            originalTextColor = progressText.color;
        }
        
        InitializeAudioButton();
        
       
        InitializeAudio();
        
      
        if (littleTurtle != null)
        {
            turtleOriginalPosition = littleTurtle.transform.position;
            
           
            Button turtleButton = littleTurtle.GetComponent<Button>();
            if (turtleButton == null)
            {
                turtleButton = littleTurtle.AddComponent<Button>();
            }
           
            turtleButton.interactable = true;
            turtleButton.transition = Selectable.Transition.ColorTint;
            
           
            ColorBlock colors = turtleButton.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(0.9f, 0.9f, 0.8f, 1f);
            colors.pressedColor = new Color(0.8f, 0.8f, 0.7f, 1f);
            colors.selectedColor = Color.white;
            colors.fadeDuration = 0.1f;
            turtleButton.colors = colors;
            
            // 设置目标图形
            Image turtleImage = littleTurtle.GetComponent<Image>();
            if (turtleImage != null)
            {
                turtleButton.targetGraphic = turtleImage;
                turtleImage.raycastTarget = true;
            }
            
            // 设置点击事件
            turtleButton.onClick.AddListener(OnTurtleClicked);
        }
        
        // 初始文字使用渐入效果
        if (progressText != null)
        {
            StartCoroutine(TextFadeIn(progressText, "请清理垃圾帮助小乌龟回家", 1.5f));
        }
        else
        {
            UpdateProgressText();
        }
    }
    
    // === 音频控制方法 ===
    
    private void InitializeAudioButton()
    {
        if (audioToggleButton != null)
        {
            audioToggleButton.onClick.AddListener(ToggleAllAudio);
        }
        
        if (narrationButton != null)
        {
            narrationButton.onClick.AddListener(ToggleNarration);
        }
        
        UpdateAudioButtonIcon();
    }
    
    private void InitializeAudio()
    {
        // 确保背景音乐自动播放
        if (bgmAudio != null && !isAudioMuted)
        {
            if (!bgmAudio.isPlaying)
            {
                bgmAudio.Play();
            }
        }
    }
    
    // 统一的声音开关 - 控制所有声音
    public void ToggleAllAudio()
    {
        PlayUISound();
        
        isAudioMuted = !isAudioMuted;
        
        // 控制所有音频源
        AudioSource[] allAudioSources = FindObjectsOfType<AudioSource>();
        foreach (AudioSource audioSource in allAudioSources)
        {
            audioSource.mute = isAudioMuted;
        }
        
        // 特殊处理：如果取消静音且BGM应该播放，重新播放
        if (!isAudioMuted && bgmAudio != null && !bgmAudio.isPlaying)
        {
            bgmAudio.Play();
        }
        
        UpdateAudioButtonIcon();
        Debug.Log(isAudioMuted ? "所有声音已静音" : "所有声音已开启");
    }
    
    // 旁白播放控制
    public void ToggleNarration()
    {
        PlayUISound();
        
        if (narrationAudio != null)
        {
            if (isNarrationPlaying)
            {
                // 暂停旁白
                narrationAudio.Pause();
                isNarrationPlaying = false;
                Debug.Log("旁白已暂停");
            }
            else
            {
                if (narrationAudio.isPlaying)
                {
                    // 恢复播放
                    narrationAudio.UnPause();
                }
                else
                {
                    // 开始播放
                    narrationAudio.Play();
                }
                isNarrationPlaying = true;
                Debug.Log("旁白开始播放");
            }
        }
        else
        {
            Debug.LogWarning("旁白音频未设置！");
        }
    }
    
   
    public void PlayNarration()
    {
        if (narrationAudio != null && !isAudioMuted)
        {
            narrationAudio.Play();
            isNarrationPlaying = true;
            Debug.Log("播放Scene3旁白");
        }
        else if (isAudioMuted)
        {
            Debug.Log("声音已静音，无法播放旁白");
        }
    }
    
   
    public void StopNarration()
    {
        if (narrationAudio != null && narrationAudio.isPlaying)
        {
            narrationAudio.Stop();
            isNarrationPlaying = false;
            Debug.Log("停止旁白");
        }
    }
  
    private void UpdateAudioButtonIcon()
    {
        if (audioOnIcon != null && audioOffIcon != null)
        {
            audioOnIcon.SetActive(!isAudioMuted);
            audioOffIcon.SetActive(isAudioMuted);
        }
    }
    
 
    private void PlayUISound()
    {
        if (uiSFX != null && !isAudioMuted)
        {
            uiSFX.Play();
        }
    }
    
    
    private void PlayTurtleSound()
    {
        if (turtleSFX != null && !isAudioMuted)
        {
            turtleSFX.Play();
        }
    }
    
    
    
    private System.Collections.IEnumerator TextFadeIn(Text textElement, string message, float duration = 0.8f)
    {
        if (textElement == null) yield break;
        
        textElement.text = message;
        textElement.color = new Color(originalTextColor.r, originalTextColor.g, originalTextColor.b, 0f);
        
        float elapsed = 0f;
        while (elapsed < duration)
        {
            float alpha = Mathf.Lerp(0f, 1f, elapsed / duration);
            textElement.color = new Color(originalTextColor.r, originalTextColor.g, originalTextColor.b, alpha);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        textElement.color = originalTextColor;
    }
    
    private System.Collections.IEnumerator RestoreTextAfterDelay(string text, float delay)
    {
        yield return new WaitForSeconds(delay);
        if (progressText != null && !isTurtleMoving)
        {
            StartCoroutine(TextFadeIn(progressText, text, 0.5f));
        }
    }
    
    // === 点击小乌龟的方法 ===
    
    private void OnTurtleClicked()
    {
        if (isTurtleMoving) return;
        
        PlayUISound();
        
        if (trashCleaned < totalTrash)
        {
            StartCoroutine(PlayTurtleBlockedAnimation());
        }
        else
        {
            StartCoroutine(PlayTurtleMoveForwardAnimation());
        }
    }
    
    // === 垃圾清理方法 ===
    
    public void CleanBottle()
    {
        if (!isTurtleMoving)
        {
            PlayUISound();
            StartCoroutine(PlayTrashDisappear(trashBottle, "塑料瓶"));
        }
    }
    
    public void CleanBanana()
    {
        if (!isTurtleMoving)
        {
            PlayUISound();
            StartCoroutine(PlayTrashDisappear(trashBanana, "香蕉皮"));
        }
    }
    
    public void CleanBag()
    {
        if (!isTurtleMoving)
        {
            PlayUISound();
            StartCoroutine(PlayTrashDisappear(trashBag, "垃圾袋"));
        }
    }
    
    // 垃圾消失动画
    private System.Collections.IEnumerator PlayTrashDisappear(GameObject trashObject, string trashName)
    {
        if (trashObject != null && trashObject.activeSelf)
        {
            if (trashCleanSound != null && !isAudioMuted)
            {
                trashCleanSound.Play();
            }
            
            Debug.Log($"开始清理 {trashName}...");
            
            float duration = 0.5f;
            float elapsed = 0f;
            Vector3 originalScale = trashObject.transform.localScale;
            
            while (elapsed < duration)
            {
                float scale = Mathf.Lerp(1f, 0f, elapsed / duration);
                trashObject.transform.localScale = originalScale * scale;
                elapsed += Time.deltaTime;
                yield return null;
            }
            
            trashObject.SetActive(false);
            trashObject.transform.localScale = originalScale;
            
            trashCleaned++;
            Debug.Log($"清理了 {trashName} ({trashCleaned}/{totalTrash})");
            UpdateProgressText();
            CheckAllTrashCleaned();
        }
    }
    
    // 乌龟受阻动画
    private System.Collections.IEnumerator PlayTurtleBlockedAnimation()
    {
        isTurtleMoving = true;
        
        Debug.Log("有垃圾挡路，小乌龟过不去！");
        
        PlayTurtleSound();
        
        string originalText = progressText != null ? progressText.text : "";
        
        if (progressText != null)
        {
            StartCoroutine(TextFadeIn(progressText, "🚫 有垃圾挡路！请先清理垃圾", 0.5f));
        }
        
        Vector3 originalPosition = littleTurtle.transform.position;
        float moveDistance = 40f;
        Vector3 targetPosition = originalPosition + new Vector3(moveDistance, 0, 0);
        
        float duration = 0.3f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            littleTurtle.transform.position = Vector3.Lerp(originalPosition, targetPosition, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        yield return new WaitForSeconds(0.2f);
        
        float shakeDuration = 0.6f;
        float shakeElapsed = 0f;
        Vector3 originalRotation = littleTurtle.transform.eulerAngles;
        
        while (shakeElapsed < shakeDuration)
        {
            float shakeAngle = Mathf.Sin(shakeElapsed * 20f) * 12f;
            littleTurtle.transform.eulerAngles = originalRotation + new Vector3(0, 0, shakeAngle);
            shakeElapsed += Time.deltaTime;
            yield return null;
        }
        
        littleTurtle.transform.eulerAngles = originalRotation;
        
        elapsed = 0f;
        while (elapsed < duration)
        {
            littleTurtle.transform.position = Vector3.Lerp(targetPosition, originalPosition, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        if (progressText != null)
        {
            StartCoroutine(RestoreTextAfterDelay(originalText, 0.5f));
        }
        
        isTurtleMoving = false;
    }
    
    // 乌龟正常前进动画
    private System.Collections.IEnumerator PlayTurtleMoveForwardAnimation()
    {
        isTurtleMoving = true;
        
        Debug.Log("道路畅通，小乌龟前进！");
        
        PlayTurtleSound();
        
        if (progressText != null)
        {
            StartCoroutine(TextFadeIn(progressText, "🎉 道路畅通！小乌龟回家了！", 0.5f));
        }
        
        Vector3 originalPosition = littleTurtle.transform.position;
        Vector3 targetPosition = originalPosition + new Vector3(400f, 0, 0);
        
        float duration = 2.0f;
        float elapsed = 0f;
        Vector3 originalScale = littleTurtle.transform.localScale;
        
        while (elapsed < duration)
        {
            float progress = elapsed / duration;
            littleTurtle.transform.position = Vector3.Lerp(originalPosition, targetPosition, progress);
            
            float floatOffset = Mathf.Sin(progress * 10f) * 15f;
            littleTurtle.transform.position += new Vector3(0, floatOffset, 0);
            
            float scale = 1f + Mathf.Sin(progress * 8f) * 0.15f;
            littleTurtle.transform.localScale = originalScale * scale;
            
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        littleTurtle.transform.localScale = originalScale;
        
        yield return new WaitForSeconds(1.5f);
        LoadNextScene();
        
        isTurtleMoving = false;
    }
    
    // 更新清理进度显示
    private void UpdateProgressText()
    {
        if (progressText != null)
        {
            string message = "";
            if (trashCleaned < totalTrash)
            {
                message = $"已清理: {trashCleaned}/{totalTrash}\n点击小乌龟尝试前进";
            }
            else
            {
                message = "✅ 所有垃圾清理完毕！\n点击小乌龟前进";
            }
            
            StartCoroutine(TextFadeIn(progressText, message, 0.5f));
        }
    }
    
    // 检查是否所有垃圾都清理完毕
    private void CheckAllTrashCleaned()
    {
        if (trashCleaned >= totalTrash)
        {
            Debug.Log("🎉 所有垃圾都清理完毕！可以继续前进了！");
            UpdateProgressText();
        }
    }
    
    // === 导航按钮方法 ===
    
    public void LoadHomeScene()
    {
        if (isTurtleMoving) return;
        PlayUISound();
        Debug.Log("返回首页");
        SceneManager.LoadScene("MainMenu");
    }
    
    public void LoadNextScene()
    {
        if (isTurtleMoving) return;
        
        if (trashCleaned >= totalTrash)
        {
            PlayUISound();
            Debug.Log("前往Scene4：到达大海");
            SceneManager.LoadScene("Scene4_SeaArrival");
        }
        else
        {
            Debug.Log("请先清理所有垃圾才能继续前进！");
        }
    }
    
    public void LoadPreviousScene()
    {
        if (isTurtleMoving) return;
        PlayUISound();
        Debug.Log("返回上一页");
        SceneManager.LoadScene("Scene2_CrabEncounter");
    }
    
    // 重新开始清理（重置场景）
    public void ResetTrashCleanup()
    {
        if (isTurtleMoving) return;
        
        PlayUISound();
        
        trashCleaned = 0;
        
        if (trashBottle != null) 
        {
            trashBottle.SetActive(true);
            trashBottle.transform.localScale = Vector3.one;
        }
        if (trashBanana != null) 
        {
            trashBanana.SetActive(true);
            trashBanana.transform.localScale = Vector3.one;
        }
        if (trashBag != null) 
        {
            trashBag.SetActive(true);
            trashBag.transform.localScale = Vector3.one;
        }
        
        if (littleTurtle != null)
        {
            littleTurtle.transform.position = turtleOriginalPosition;
            littleTurtle.transform.eulerAngles = Vector3.zero;
            littleTurtle.transform.localScale = Vector3.one;
        }
        
        UpdateProgressText();
        Debug.Log("重置垃圾清理进度");
    }
    
    // 提供给外部检查声音状态的方法
    public bool IsAudioMuted()
    {
        return isAudioMuted;
    }
    
    // 检查旁白是否在播放
    public bool IsNarrationPlaying()
    {
        return isNarrationPlaying;
    }
}