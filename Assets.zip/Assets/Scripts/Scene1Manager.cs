using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Scene1Manager : MonoBehaviour
{
    public AudioSource narrationAudio;
    
    
    public AudioSource uiClickAudio;
    
 
    public GameObject littleTurtle;
    
    public GameObject egg;
    
   
    public Button audioToggleButton;
    
   
    public GameObject audioOnIcon;
    public GameObject audioOffIcon;
    
   
    private bool isAudioMuted = false;
    
    void Start()
    {
        Debug.Log("Scene1_Introduction 加载完成！");
        
      
        if (littleTurtle != null)
            littleTurtle.SetActive(false);
        
        if (egg != null)
            egg.SetActive(true);
            
   
        if (audioToggleButton != null)
        {
            audioToggleButton.onClick.AddListener(ToggleAllAudio);
        }
        
  
        UpdateAudioButtonIcon();
    }
    
 
    public void LoadHomeScene()
    {
        PlayUIClickSound();
        Debug.Log("返回首页");
        SceneManager.LoadScene("MainMenu");
    }
    
 
    public void LoadNextScene()
    {
        PlayUIClickSound();
        Debug.Log("前往下一页");
        SceneManager.LoadScene("Scene2_CrabEncounter");
    }
    
    public void LoadPreviousScene()
    {
        PlayUIClickSound();
        Debug.Log("返回上一页");
        SceneManager.LoadScene("MainMenu");
    }
    
    public void PlayNarration()
    {
        PlayUIClickSound();
        
        if (narrationAudio != null && !isAudioMuted)
        {
            narrationAudio.Play();
            Debug.Log("播放旁白：小海龟的困惑");
        }
        else if (isAudioMuted)
        {
            Debug.Log("声音已静音，无法播放旁白");
        }
        else
        {
            Debug.LogWarning("旁白音频未设置！");
        }
    }
    
 
    public void StopNarration()
    {
        if (narrationAudio != null && narrationAudio.isPlaying)
        {
            narrationAudio.Stop();
        }
    }
    
   
    public void PlayUIClickSound()
    {
        if (uiClickAudio != null && !isAudioMuted)
        {
            uiClickAudio.Play();
        }
    }
    
 
    public void OnEggClicked()
    {
        PlayUIClickSound();
        Debug.Log("蛋被点击了！");
        
      
        if (egg != null)
        {
          
            egg.SetActive(false);
        }
        
        if (littleTurtle != null)
        {
            littleTurtle.SetActive(true);
            
            
            Animator turtleAnimator = littleTurtle.GetComponent<Animator>();
            if (turtleAnimator != null)
            {
                turtleAnimator.SetTrigger("Appear");
            }
            
            Debug.Log("小乌龟出现了！");
        }
    }
    
    
    public void OnTurtleClicked()
    {
        PlayUIClickSound();
        Debug.Log("小乌龟被点击了！");
        
        if (littleTurtle != null)
        {
          
            Animator turtleAnimator = littleTurtle.GetComponent<Animator>();
            if (turtleAnimator != null)
            {
                turtleAnimator.SetTrigger("Action");
            }
            
           
            StartCoroutine(TurtleActionAnimation());
        }
    }
    

    private System.Collections.IEnumerator TurtleActionAnimation()
    {
        Vector3 originalScale = littleTurtle.transform.localScale;
        Vector3 targetScale = originalScale * 1.2f;
        
        float duration = 0.2f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            littleTurtle.transform.localScale = Vector3.Lerp(originalScale, targetScale, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
     
        elapsed = 0f;
        while (elapsed < duration)
        {
            littleTurtle.transform.localScale = Vector3.Lerp(targetScale, originalScale, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        littleTurtle.transform.localScale = originalScale;
    }
    
    
    public void ToggleAllAudio()
    {
        isAudioMuted = !isAudioMuted;
        
        AudioSource[] allAudioSources = FindObjectsOfType<AudioSource>();
        foreach (AudioSource audioSource in allAudioSources)
        {
            audioSource.mute = isAudioMuted;
        }
        
    
        if (isAudioMuted && narrationAudio != null && narrationAudio.isPlaying)
        {
            narrationAudio.Pause();
        }
        
        else if (!isAudioMuted && narrationAudio != null)
        {
            narrationAudio.UnPause();
        }
        
       
        UpdateAudioButtonIcon();
        
        Debug.Log(isAudioMuted ? "所有声音已静音" : "所有声音已开启");
    }
    

    private void UpdateAudioButtonIcon()
    {
        if (audioOnIcon != null && audioOffIcon != null)
        {
            audioOnIcon.SetActive(!isAudioMuted);
            audioOffIcon.SetActive(isAudioMuted);
        }
    }
    
 
    public bool IsAudioMuted()
    {
        return isAudioMuted;
    }
}