using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;

public class Scene4Manager : MonoBehaviour
{
    // 音频源引用
    public AudioSource narrationAudio;
    public AudioSource bgmAudio;
    public AudioSource uiSFX;
    public AudioSource celebrationSound;
    
    // 引用对象
    public GameObject littleTurtle;
    public Text dialogueText;
    public Text titleText;
    
    // 声音控制相关
    public Button audioToggleButton;
    public GameObject audioOnIcon;
    public GameObject audioOffIcon;
    private bool isAudioMuted = false;
    
    // 动画控制
    private bool isAnimationPlaying = false;
    
    void Start()
    {
        Debug.Log("Scene4_到达大海 加载完成！");
        
        // 初始化声音按钮
        InitializeAudioButton();
        
        // 初始化音频
        if (bgmAudio != null && !isAudioMuted)
        {
            bgmAudio.Play();
        }
        
        // 开始场景动画
        StartCoroutine(PlayArrivalAnimation());
    }
    
    // 初始化声音按钮
    private void InitializeAudioButton()
    {
        if (audioToggleButton != null)
        {
            audioToggleButton.onClick.AddListener(ToggleAllAudio);
        }
        
        UpdateAudioButtonIcon();
    }
    
    // === 声音控制方法 ===
    
    public void ToggleAllAudio()
    {
        PlayUISound();
        
        isAudioMuted = !isAudioMuted;
        
        // 控制所有音频源
        AudioSource[] allAudioSources = FindObjectsOfType<AudioSource>();
        foreach (AudioSource audioSource in allAudioSources)
        {
            audioSource.mute = isAudioMuted;
        }
        
        // 特殊处理：如果取消静音且BGM应该播放，重新播放
        if (!isAudioMuted && bgmAudio != null && !bgmAudio.isPlaying)
        {
            bgmAudio.Play();
        }
        
        UpdateAudioButtonIcon();
        Debug.Log(isAudioMuted ? "所有声音已静音" : "所有声音已开启");
    }
    
    // 更新声音按钮图标
    private void UpdateAudioButtonIcon()
    {
        if (audioOnIcon != null && audioOffIcon != null)
        {
            audioOnIcon.SetActive(!isAudioMuted);
            audioOffIcon.SetActive(isAudioMuted);
        }
    }
    
    // === 场景动画 ===
    
    private System.Collections.IEnumerator PlayArrivalAnimation()
    {
        isAnimationPlaying = true;
        
        // 初始文字
        if (dialogueText != null)
        {
            StartCoroutine(TextFadeIn(dialogueText, "我终于到大海了！", 1.0f));
        }
        
        // 播放庆祝音效
        if (celebrationSound != null && !isAudioMuted)
        {
            celebrationSound.Play();
        }
        
        // 等待一下
        yield return new WaitForSeconds(2f);
        
        // 小乌龟开心动画
        yield return StartCoroutine(PlayTurtleCelebration());
        
        // 显示感谢文字
        if (dialogueText != null)
        {
            StartCoroutine(TextFadeIn(dialogueText, "谢谢你帮助我回家！", 1.0f));
        }
        
        yield return new WaitForSeconds(2f);
        
        // 显示结束提示
        if (dialogueText != null)
        {
            StartCoroutine(TextFadeIn(dialogueText, "故事结束！点击继续...", 1.0f));
        }
        
        isAnimationPlaying = false;
    }
    
    // 小乌龟庆祝动画
    private System.Collections.IEnumerator PlayTurtleCelebration()
    {
        if (littleTurtle == null) yield break;
        
        Vector3 originalPosition = littleTurtle.transform.position;
        Vector3 originalScale = littleTurtle.transform.localScale;
        
        // 动画1：高兴跳跃
        float duration = 1.5f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            float progress = elapsed / duration;
            
            // 上下跳跃
            float jumpHeight = Mathf.Sin(progress * 8f) * 30f;
            littleTurtle.transform.position = originalPosition + new Vector3(0, jumpHeight, 0);
            
            // 开心缩放
            float scale = 1f + Mathf.Sin(progress * 6f) * 0.2f;
            littleTurtle.transform.localScale = originalScale * scale;
            
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        // 恢复原始状态
        littleTurtle.transform.position = originalPosition;
        littleTurtle.transform.localScale = originalScale;
    }
    
    // === 文字渐入效果 ===
    
    private System.Collections.IEnumerator TextFadeIn(Text textElement, string message, float duration = 0.8f)
    {
        if (textElement == null) yield break;
        
        Color originalColor = textElement.color;
        textElement.text = message;
        textElement.color = new Color(originalColor.r, originalColor.g, originalColor.b, 0f);
        
        float elapsed = 0f;
        while (elapsed < duration)
        {
            float alpha = Mathf.Lerp(0f, 1f, elapsed / duration);
            textElement.color = new Color(originalColor.r, originalColor.g, originalColor.b, alpha);
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        textElement.color = originalColor;
    }
    
    // === 按钮方法 ===
    
    public void LoadHomeScene()
    {
        if (isAnimationPlaying) return;
        PlayUISound();
        Debug.Log("返回首页");
        SceneManager.LoadScene("MainMenu");
    }
    
    public void LoadCreditsScene()
    {
        if (isAnimationPlaying) return;
        PlayUISound();
        Debug.Log("前往致谢页面");
        SceneManager.LoadScene("CreditsPage");
    }
    
    public void LoadPreviousScene()
    {
        if (isAnimationPlaying) return;
        PlayUISound();
        Debug.Log("返回上一页");
        SceneManager.LoadScene("Scene3_TrashCleanup");
    }
    
    public void PlayNarration()
    {
        if (isAnimationPlaying) return;
        PlayUISound();
        
        if (narrationAudio != null && !isAudioMuted)
        {
            narrationAudio.Play();
            Debug.Log("播放Scene4旁白");
        }
        else if (isAudioMuted)
        {
            Debug.Log("声音已静音，无法播放旁白");
        }
    }
    
    private void PlayUISound()
    {
        if (uiSFX != null && !isAudioMuted)
        {
            uiSFX.Play();
        }
    }
    
    // 提供给外部检查声音状态的方法
    public bool IsAudioMuted()
    {
        return isAudioMuted;
    }
}