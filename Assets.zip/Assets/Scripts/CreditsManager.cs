using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using System.Collections.Generic;

public class CreditsManager : MonoBehaviour
{
    [Header("Data Configuration")]
    public CreditsData creditsData;
    
    [Header("UI References")]
    public TextMeshProUGUI creditsText;
    public CanvasGroup textCanvasGroup;
    
    [Header("Buttons")]
    public Button homeButton;
    public Button audioToggleButton;
    public Button previousButton; 
    public Button nextButton;      
    
    [Header("Audio")]
    public AudioSource bgmAudio;
    public AudioSource uiClickAudio;
    
    [Header("Icons")]
    public GameObject audioOnIcon;
    public GameObject audioOffIcon;
    
    [Header("Display Settings")]
    public float lineDelay = 3.2f;
    public float fadeInDuration = 1.6f;
    public float initialDelay = 1.5f;
    public float finalStayTime = 4f;
    
    private bool isAudioMuted = false;
    private List<string> creditLines = new List<string>();
    private Coroutine displayCoroutine;

    void Awake()
    {
        CheckRequiredComponents();
    }

    void Start()
    {
        Debug.Log("Credits scene loaded!");
        InitializeCredits();
    }

    void CheckRequiredComponents()
    {
        if (creditsText == null)
        {
            Debug.LogError("CreditsText is not assigned! Please drag the TextMeshPro object.");
        }
        
        if (homeButton == null)
        {
            Debug.LogError("HomeButton is not assigned!");
        }
        
        if (audioToggleButton == null)
        {
            Debug.LogError("AudioToggleButton is not assigned!");
        }
        
        if (previousButton == null)
        {
            Debug.LogWarning("PreviousButton is not assigned - previous page functionality will not work.");
        }
        
        if (bgmAudio == null)
        {
            Debug.LogWarning("BGM Audio is not assigned - background music will not play.");
        }
    }

    void InitializeCredits()
    {
        if (creditsText == null)
        {
            Debug.LogError("Cannot initialize credits - CreditsText is null!");
            return;
        }

      
        if (homeButton != null)
        {
            homeButton.onClick.AddListener(LoadHomeScene);
        }
        
        if (audioToggleButton != null)
        {
            audioToggleButton.onClick.AddListener(ToggleAudio);
        }
        
        if (previousButton != null)
        {
            previousButton.onClick.AddListener(LoadPreviousScene);
        }
        
        if (nextButton != null)
        {
            nextButton.onClick.AddListener(LoadNextScene);
        }
        
        LoadCreditsFromData();
        UpdateAudioButtonIcon();
        
        if (creditLines.Count > 0)
        {
            displayCoroutine = StartCoroutine(DisplayCreditsSequence());
        }
        else
        {
            Debug.LogError("No credit lines to display!");
        }
        
        PlayBGM();
    }

    void LoadCreditsFromData()
    {
        creditLines.Clear();
        
        if (creditsData != null && creditsData.creditSections.Count > 0)
        {
            Debug.Log($"Loading credits data with {creditsData.creditSections.Count} sections");
            
            foreach (var section in creditsData.creditSections)
            {
                if (!string.IsNullOrEmpty(section.sectionTitle))
                {
                    creditLines.Add(section.sectionTitle.ToUpper());
                    creditLines.Add("");
                }
                
                if (!string.IsNullOrEmpty(section.sectionContent))
                {
                    string[] contentLines = section.sectionContent.Split('\n');
                    foreach (string line in contentLines)
                    {
                        string trimmedLine = line.Trim();
                        if (!string.IsNullOrEmpty(trimmedLine))
                        {
                            creditLines.Add(trimmedLine);
                        }
                    }
                }
                
                creditLines.Add("");
            }
            
            if (creditLines.Count > 0 && string.IsNullOrEmpty(creditLines[creditLines.Count - 1]))
            {
                creditLines.RemoveAt(creditLines.Count - 1);
            }
            
            creditLines.Add("");
            creditLines.Add("THANK YOU FOR PLAYING!");
        }
        else
        {
            creditLines.Add("Credits data not configured");
            creditLines.Add("Please set CreditsData in Inspector");
            creditLines.Add("");
            creditLines.Add("Thank you for playing!");
        }
        
        Debug.Log($"Loaded {creditLines.Count} credit lines");
    }

   
    
    public void LoadHomeScene()
    {
        PlayUIClickSound();
        Debug.Log("Returning to main menu");
        SceneManager.LoadScene("MainMenu");
    }
    
    public void LoadPreviousScene()
    {
        PlayUIClickSound();
        Debug.Log("Loading previous scene");
       
        SceneManager.LoadScene("Scene4_SeaArrival"); 
    }
    
    public void LoadNextScene()
    {
        PlayUIClickSound();
        Debug.Log("Loading next scene");
       
        
    }

    IEnumerator DisplayCreditsSequence()
    {
        if (creditsText == null)
        {
            Debug.LogError("Cannot start credits sequence - CreditsText is null!");
            yield break;
        }

        yield return new WaitForSeconds(initialDelay);
        
        foreach (string line in creditLines)
        {
            yield return StartCoroutine(DisplayLine(line));
            yield return new WaitForSeconds(lineDelay);
        }
        
        yield return new WaitForSeconds(finalStayTime);
        RestartCredits();
    }

    IEnumerator DisplayLine(string line)
    {
        if (creditsText == null)
        {
            Debug.LogError("CreditsText is null in DisplayLine!");
            yield break;
        }
        
        creditsText.text = line;
        
        if (textCanvasGroup != null)
        {
            textCanvasGroup.alpha = 0f;
            float timer = 0f;
            
            while (timer < fadeInDuration)
            {
                timer += Time.deltaTime;
                textCanvasGroup.alpha = Mathf.Lerp(0f, 1f, timer / fadeInDuration);
                yield return null;
            }
            textCanvasGroup.alpha = 1f;
        }
        else
        {
            creditsText.color = new Color(creditsText.color.r, creditsText.color.g, creditsText.color.b, 1f);
        }
    }

    void RestartCredits()
    {
        if (displayCoroutine != null)
        {
            StopCoroutine(displayCoroutine);
        }
        
        displayCoroutine = StartCoroutine(DisplayCreditsSequence());
    }

    public void SkipAnimation()
    {
        PlayUIClickSound();
        
        if (displayCoroutine != null)
        {
            StopCoroutine(displayCoroutine);
        }
        
        string fullText = string.Join("\n", creditLines);
        creditsText.text = fullText;
        
        if (textCanvasGroup != null)
        {
            textCanvasGroup.alpha = 1f;
        }
        
        Debug.Log("Credits animation skipped");
    }

    public void RestartAnimation()
    {
        PlayUIClickSound();
        
        if (textCanvasGroup != null)
        {
            textCanvasGroup.alpha = 0f;
        }
        RestartCredits();
        
        Debug.Log("Credits animation restarted");
    }

    void PlayBGM()
    {
        if (bgmAudio != null && !isAudioMuted)
        {
            bgmAudio.Play();
            Debug.Log("Background music started");
        }
    }

    public void PlayUIClickSound()
    {
        if (uiClickAudio != null && !isAudioMuted)
        {
            uiClickAudio.Play();
        }
    }

    public void ToggleAudio()
    {
        PlayUIClickSound();
        
        isAudioMuted = !isAudioMuted;
        
        AudioSource[] allAudioSources = FindObjectsOfType<AudioSource>();
        foreach (AudioSource audioSource in allAudioSources)
        {
            audioSource.mute = isAudioMuted;
        }
        
        UpdateAudioButtonIcon();
        Debug.Log(isAudioMuted ? "Audio muted" : "Audio enabled");
    }

    void UpdateAudioButtonIcon()
    {
        if (audioOnIcon != null && audioOffIcon != null)
        {
            audioOnIcon.SetActive(!isAudioMuted);
            audioOffIcon.SetActive(isAudioMuted);
        }
    }

    public bool IsAudioMuted()
    {
        return isAudioMuted;
    }

    public void ChangeCreditsData(CreditsData newData)
    {
        creditsData = newData;
        LoadCreditsFromData();
        RestartAnimation();
    }

    void OnDestroy()
    {
        if (displayCoroutine != null)
        {
            StopCoroutine(displayCoroutine);
        }
    }
}